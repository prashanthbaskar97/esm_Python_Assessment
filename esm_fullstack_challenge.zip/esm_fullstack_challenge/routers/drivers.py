from typing import List
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel,field_validator
from fastapi import Request
from typing import Union


from esm_fullstack_challenge.models import AutoGenModels
from esm_fullstack_challenge.routers.utils import get_route_list_function, get_route_id_function
from esm_fullstack_challenge.dependencies import get_db
from esm_fullstack_challenge.db import DB

drivers_router = APIRouter()
table_model = AutoGenModels['drivers']

# --------------------- GET: Single & List ---------------------

get_driver = get_route_id_function('drivers', table_model)
drivers_router.add_api_route(
    '/{id}', get_driver, methods=["GET"], response_model=table_model
)

get_drivers = get_route_list_function('drivers', table_model)
drivers_router.add_api_route(
    '', get_drivers, methods=["GET"], response_model=List[table_model]
)

# --------------------- Schema ---------------------

class DriverCreate(BaseModel):
    driver_ref: str
    number: str
    code: str
    forename: str
    surname: str
    dob: str  # YYYY-MM-DD
    nationality: str
    url: str

    

# --------------------- POST ---------------------

@drivers_router.post('', response_model=table_model)
def create_driver(driver: DriverCreate,request: Request, db: DB = Depends(get_db)):
    # Validate the URL format
    with db.get_connection() as conn:
        cursor = conn.cursor()
        try:
            cursor.execute(
                """
                INSERT INTO drivers (driver_ref, number, code, forename, surname, dob, nationality, url)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    driver.driver_ref,
                    driver.number,
                    driver.code,
                    driver.forename,
                    driver.surname,
                    driver.dob,
                    driver.nationality,
                    driver.url,
                )
            )
            conn.commit()
            new_id = cursor.lastrowid
            return table_model(id=new_id, **driver.dict())
        except Exception as e:
            conn.rollback()
            raise HTTPException(status_code=400, detail=f"Create failed: {str(e)}")

# --------------------- PUT ---------------------

@drivers_router.put('/{id}', response_model=table_model)
def update_driver(id: int, driver: DriverCreate, db: DB = Depends(get_db)):
    with db.get_connection() as conn:
        cursor = conn.cursor()
        try:
            cursor.execute(
                """
                UPDATE drivers
                SET driver_ref = ?, number = ?, code = ?, forename = ?, surname = ?, dob = ?, nationality = ?, url = ?
                WHERE id = ?
                """,
                (
                    driver.driver_ref,
                    driver.number,
                    driver.code,
                    driver.forename,
                    driver.surname,
                    driver.dob,
                    driver.nationality,
                    driver.url,
                    id,
                )
            )

            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Driver not found")

            conn.commit()
            return table_model(id=id, **driver.dict())
        except Exception as e:
            conn.rollback()
            raise HTTPException(status_code=400, detail=f"Update failed: {str(e)}")

# --------------------- DELETE ---------------------

@drivers_router.delete('/{id}', response_model=table_model)
def delete_driver(id: int, db: DB = Depends(get_db)):
    with db.get_connection() as conn:
        cursor = conn.cursor()
        try:
            existing = cursor.execute(
                "SELECT * FROM drivers WHERE id = ?",
                (id,)
            ).fetchone()

            if not existing:
                raise HTTPException(status_code=404, detail="Driver not found")

            cursor.execute("DELETE FROM drivers WHERE id = ?", (id,))
            conn.commit()

            return table_model(**existing)
        except Exception as e:
            conn.rollback()
            raise HTTPException(status_code=400, detail=f"Delete failed: {str(e)}")
