# flake8: noqa
from esm_fullstack_challenge.models.utils import autogen_models

AutoGenModels = autogen_models()
