"""Top-level package for ESM FullStack Challenge."""

__author__ = """Excel Sports"""
__email__ = 'esm@email.com'
__version__ = '0.1.0'
